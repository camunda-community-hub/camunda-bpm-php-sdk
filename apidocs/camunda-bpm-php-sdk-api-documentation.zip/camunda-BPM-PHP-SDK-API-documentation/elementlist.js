
var ApiGen = ApiGen || {};
ApiGen.elements = [["c","org\\camunda\\php\\sdk\\camundaRestClient"]];
